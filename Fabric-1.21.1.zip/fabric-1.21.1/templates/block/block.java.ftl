<#--
 # This file is part of Fabric-Generator-MCreator.
 # Copyright (C) 2012-2020, Pylo
 # Copyright (C) 2020-2026, Pylo, opensource contributors
 # Copyright (C) 2020-2026, Goldorion, opensource contributors
 #
 # Fabric-Generator-MCreator is free software: you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation, either version 3 of the License, or
 # (at your option) any later version.
 #
 # Fabric-Generator-MCreator is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with Fabric-Generator-MCreator. If not, see <https://www.gnu.org/licenses/>.
-->

<#-- @formatter:off -->
<#include "../boundingboxes.java.ftl">
<#include "../mcitems.ftl">
<#include "../procedures.java.ftl">
<#include "../triggers.java.ftl">
<#assign biomeSelector = "includeByKey">
<#assign resourceKey = "ResourceKey">
<#if data.restrictionBiomes?has_content>
	<#list w.filterBrokenReferences(data.restrictionBiomes) as restrictionBiome>
		<#if restrictionBiome?contains("#")>
			<#assign biomeSelector = "tag">
			<#assign resourceKey = "TagKey">
			<#break>
		</#if>
	</#list>
</#if>

<#assign filteredCustomProperties = data.customProperties?filter(e ->
	e.property().getName().startsWith("CUSTOM:") || generator.map(e.property().getName(), "blockstateproperties") != "")>

package ${package}.block;

import com.mojang.serialization.MapCodec;

import net.minecraft.core.*;
import net.minecraft.core.registries.*;
import net.minecraft.resources.*;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.tags.*;
import net.minecraft.util.*;
import net.minecraft.util.valueproviders.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

import java.util.*;
import java.util.function.*;

import net.fabricmc.api.*;
import net.fabricmc.fabric.api.biome.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.fabricmc.fabric.api.registry.*;


<@javacompress>
public class ${getClassName()}Block extends ${getBlockClass(data.blockBase)}

	<#assign interfaces = []>
	<#if data.isWaterloggable>
		<#assign interfaces += ["SimpleWaterloggedBlock"]>
	</#if>
	<#if data.hasInventory>
		<#assign interfaces += ["EntityBlock"]>
	</#if>
	<#if data.isBonemealable && !(data.blockBase?has_content && data.blockBase == "TrapDoor")>
		<#assign interfaces += ["BonemealableBlock"]>
	</#if>
	<#if interfaces?size gt 0>
		implements ${interfaces?join(",")}
	</#if>
{

	<#if data.rotationMode == 1 || data.rotationMode == 3>
		public static final EnumProperty<Direction> FACING = HorizontalDirectionalBlock.FACING;
		<#if data.enablePitch>
		public static final EnumProperty<AttachFace> FACE = FaceAttachedHorizontalDirectionalBlock.FACE;
		</#if>
	<#elseif data.rotationMode == 2 || data.rotationMode == 4>
		public static final EnumProperty<Direction> FACING = DirectionalBlock.FACING;
	<#elseif data.rotationMode == 5>
		public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.AXIS;
	</#if>
	<#if data.isWaterloggable>
		public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;
	</#if>
	<#list filteredCustomProperties as prop>
		<#if prop.property().getName().startsWith("CUSTOM:")>
			<#assign propName = prop.property().getName().replace("CUSTOM:", "")>
			<#if prop.property().getClass().getSimpleName().equals("LogicType")>
				public static final BooleanProperty ${propName?upper_case} = BooleanProperty.create("${propName}");
			<#elseif prop.property().getClass().getSimpleName().equals("IntegerType")>
				public static final IntegerProperty ${propName?upper_case} = IntegerProperty.create("${propName}", ${prop.property().getMin()}, ${prop.property().getMax()});
			<#elseif prop.property().getClass().getSimpleName().equals("StringType")>
				public static final EnumProperty<${StringUtils.snakeToCamel(propName)}Property> ${propName?upper_case} = EnumProperty.create("${propName}", ${StringUtils.snakeToCamel(propName)}Property.class);
			</#if>
		<#else>
			<#assign propName = prop.property().getName()>
			<#if prop.property().getClass().getSimpleName().equals("LogicType")>
				public static final BooleanProperty ${propName?upper_case} = ${generator.map(propName, "blockstateproperties")};
			<#elseif prop.property().getClass().getSimpleName().equals("IntegerType")>
				public static final IntegerProperty ${propName?upper_case} = ${generator.map(propName, "blockstateproperties")};
			<#elseif prop.property().getClass().getSimpleName().equals("StringType")>
				public static final EnumProperty<${generator.map(propName, "blockstateproperties", 2)}> ${propName?upper_case} = ${generator.map(propName, "blockstateproperties")};
			</#if>
		</#if>
	</#list>

	<#assign defaultStateCustomShape = data.boundingBoxes?? && !data.blockBase?? && !data.isFullCube()>
	<#assign statesWithCustomShape = data.getDefinedStatesWithCustomShape()>
	<#if data.transparencyType != "SOLID" || data.hasTransparency>
	@Environment(EnvType.CLIENT) public static void registerRenderLayer() {
		<#if data.transparencyType == "TRANSLUCENT">
		BlockRenderLayerMap.putBlock(${JavaModName}Blocks.${REGISTRYNAME}, ChunkSectionLayer.TRANSLUCENT);
		<#elseif data.transparencyType == "CUTOUT" || data.transparencyType == "CUTOUT_MIPPED" || data.hasTransparency>
		BlockRenderLayerMap.putBlock(${JavaModName}Blocks.${REGISTRYNAME}, ChunkSectionLayer.CUTOUT);
		<#else>
		BlockRenderLayerMap.putBlock(${JavaModName}Blocks.${REGISTRYNAME}, ChunkSectionLayer.SOLID);
		</#if>
	}

	</#if>
	<#if defaultStateCustomShape || statesWithCustomShape?has_content>
		<#if data.rotationMode == 0 && !statesWithCustomShape?has_content><#-- shape not state dependent -->
		private static final VoxelShape SHAPE = <@boundingBoxWithRotation data/>;
		<#else>
		private final Function<BlockState, VoxelShape> shapes = this.makeShapes();
		</#if>
	</#if>

	<#if data.hasGravity>
	public static final MapCodec<${name}Block> CODEC = simpleCodec(${name}Block::new);

	@Override public MapCodec<${name}Block> codec() {
		return CODEC;
	}

	@Override public int getDustColor(BlockState blockstate, BlockGetter world, BlockPos pos) {
		return blockstate.getMapColor(world, pos).col;
	}
	</#if>

	<#macro blockProperties>
		properties
		<#if (data.colorOnMap!"DEFAULT") != "DEFAULT">
			.mapColor(MapColor.${data.colorOnMap})
		</#if>
		<#if data.isCustomSoundType>
			.sound(new SoundType(1.0f, 1.0f,
			        BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("${data.breakSound}")),
			        BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("${data.stepSound}")),
			        BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("${data.placeSound}")),
			        BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("${data.hitSound}")),
			        BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("${data.fallSound}"))))
		<#elseif data.soundOnStep != "STONE">
			.sound(SoundType.${data.soundOnStep})
		</#if>
		<#if data.unbreakable>
			.strength(-1, 3600000)
		<#elseif (data.hardness == 0) && (data.resistance == 0)>
			.instabreak()
		<#elseif data.hardness == data.resistance>
			.strength(${data.hardness}f)
		<#else>
			.strength(${data.hardness}f, ${data.resistance}f)
		</#if>
		<#if hasProcedure(data.luminance) || data.luminance.getFixedValue() != 0>
			.lightLevel(blockstate -> <#if hasProcedure(data.luminance)>(int) <@procedureOBJToNumberCode data.luminance/><#else>${data.luminance.getFixedValue()}</#if>)
		</#if>
		<#if data.requiresCorrectTool>
			.requiresCorrectToolForDrops()
		</#if>
		<#if data.isNotColidable>
			.noCollision()
		</#if>
		<#if data.slipperiness != 0.6>
			.friction(${data.slipperiness}f)
		</#if>
		<#if data.speedFactor != 1.0>
			.speedFactor(${data.speedFactor}f)
		</#if>
		<#if data.jumpFactor != 1.0>
			.jumpFactor(${data.jumpFactor}f)
		</#if>
		<#if (data.hasTransparency || data.blockBase! == "Leaves") && !data.isNotColidable> <#-- No collision implies no occlusion -->
			.noOcclusion()
		</#if>
		<#if data.tickRandomly>
			.randomTicks()
		</#if>
		<#if data.reactionToPushing != "NORMAL">
			.pushReaction(PushReaction.${data.reactionToPushing})
		</#if>
		<#if data.emissiveRendering>
			.hasPostProcess((bs, br, bp) -> true)
			.emissiveRendering((bs, br, bp) -> true)
		</#if>
		<#if data.hasTransparency>
			.isRedstoneConductor((bs, br, bp) -> false)
		</#if>
		<#if (!data.isNotColidable && data.offsetType != "NONE")>
			.dynamicShape()
		</#if>
		<#if data.isReplaceable>
			.replaceable()
		</#if>
		<#if data.offsetType != "NONE">
			.offsetType(Block.OffsetType.${data.offsetType})
		</#if>
		<#if data.ignitedByLava>
			.ignitedByLava()
		</#if>
		<#if data.noteBlockInstrument.getUnmappedValue() != "harp">
			.instrument(${data.noteBlockInstrument})
		</#if>
		<#if data.blockBase?has_content && (
				data.blockBase == "FenceGate" ||
				data.blockBase == "PressurePlate" ||
				data.blockBase == "Fence" ||
				data.blockBase == "Wall" ||
				data.blockBase == "Sign" ||
				data.blockBase == "HangingSign")>
			.forceSolidOn()
		</#if>
		<#if data.blockBase?has_content && data.blockBase == "EndRod">
			.forceSolidOff()
		</#if>
		<#if data.blockBase?has_content && data.blockBase == "Leaves">
			.isSuffocating((bs, br, bp) -> false)
			.isViewBlocking((bs, br, bp) -> false)
		</#if>
		<#if var_extends_class! == "WallSignBlock" || var_extends_class! == "WallHangingSignBlock">
			.overrideLootTable(${JavaModName}Blocks.${REGISTRYNAME}.getLootTable())
			.overrideDescription(${JavaModName}Blocks.${REGISTRYNAME}.getDescriptionId())
		</#if>
	</#macro>

	public ${getClassName()}Block(BlockBehaviour.Properties properties) {
		<#if data.blockBase?has_content>
			<#if data.blockBase == "Stairs">
				super(Blocks.AIR.defaultBlockState(), <@blockProperties/>);
			<#elseif data.blockBase == "Leaves">
				super(${data.leavesParticleChance}f,
						<#if data.leavesParticleType??>${data.leavesParticleType},
						<#elseif data.tintType == "No tint">ColorParticleOption.create(ParticleTypes.TINTED_LEAVES, ${data.getLeavesParticleColor()}),
						</#if><@blockProperties/>);
			<#elseif data.blockBase == "PressurePlate" || data.blockBase == "TrapDoor" || data.blockBase == "Door">
				super(BlockSetType.${data.blockSetType}, <@blockProperties/>);
			<#elseif data.blockBase == "Button">
				super(BlockSetType.${data.blockSetType}, <#if data.blockSetType == "OAK">30<#else>20</#if>, <@blockProperties/>);
			<#elseif data.blockBase == "FenceGate">
				super(WoodType.OAK, <@blockProperties/>);
			<#elseif data.blockBase == "FlowerPot">
				super(${mappedBlockToBlock(data.pottedPlant)}, <@blockProperties/>);
			<#elseif data.isSign()>
				super(${JavaModName}WoodTypes.${REGISTRYNAME}_WOOD_TYPE, <@blockProperties/>);
			<#else>
				super(<@blockProperties/>);
			</#if>
		<#else>
			super(<@blockProperties/>);
		</#if>

		<#if data.rotationMode != 0 || data.isWaterloggable || filteredCustomProperties?has_content>
		this.registerDefaultState(this.stateDefinition.any()
			<#if data.rotationMode == 1 || data.rotationMode == 3>
			.setValue(FACING, Direction.NORTH)
				<#if data.enablePitch>
				.setValue(FACE, AttachFace.WALL)
				</#if>
			<#elseif data.rotationMode == 2 || data.rotationMode == 4>
			.setValue(FACING, Direction.NORTH)
			<#elseif data.rotationMode == 5>
			.setValue(AXIS, Direction.Axis.Y)
			</#if>
			<@initCustomBlockStateProperties />
			<#if data.isWaterloggable>
			.setValue(WATERLOGGED, false)
			</#if>
		);
		</#if>

		<#if data.flammability != 0 && data.fireSpreadSpeed != 0>
			FlammableBlockRegistry.getDefaultInstance().add(this, ${data.flammability}, ${data.fireSpreadSpeed});
		</#if>
	}

	<#if data.generateFeature>
        public static final Predicate<BiomeSelectionContext> GENERATE_BIOMES = BiomeSelectors.
        <#if data.restrictionBiomes?has_content>
        ${biomeSelector}(
            <#list w.filterBrokenReferences(data.restrictionBiomes) as restrictionBiome>
                ${resourceKey}.create(Registries.BIOME, ResourceLocation.parse("${restrictionBiome?replace("#", "")}"))<#sep>,
            </#list>
        )
        <#else>
        all()
        </#if>;
	</#if>

	<#if defaultStateCustomShape || statesWithCustomShape?has_content>
		<#if data.rotationMode != 0 || statesWithCustomShape?has_content>
		private Function<BlockState, VoxelShape> makeShapes() {
			return this.getShapeForEachState(state -> {
				<#list statesWithCustomShape as state>
					<#if !state?is_first>else </#if>if (
					<#list state.stateMap.keySet() as property>
						<#assign value = state.stateMap.get(property)>
						<#if property.getClass().getSimpleName().equals("StringType")>
							<#assign value = generator.map(property.getName(), "blockstateproperties", 2) + "." + value?upper_case>
						</#if>
						state.getValue(${property.getName().replace("CUSTOM:", "")?upper_case}) == ${value}<#sep>&&
					</#list>
				) {
					return <@boundingBoxWithRotation state data.rotationMode data.enablePitch/>;
				}
				</#list>
				return <@boundingBoxWithRotation data data.rotationMode data.enablePitch/>;
			}
			<#-- exclude states that don't affect shape -->
			<#assign usedProperties = data.getPropertiesUsedInStates()>
			<#if data.isWaterloggable && !usedProperties?contains("waterlogged")>,WATERLOGGED</#if>
			<#list filteredCustomProperties as prop>
				<#if !usedProperties?contains(prop.property().getName())>
				,${prop.property().getName().replace("CUSTOM:", "")?upper_case}
				</#if>
			</#list>
			);
		}
		</#if>

		@Override public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
			<#assign offset = !data.shouldDisableOffset() && !data.isBoundingBoxEmpty()>

			<#if data.rotationMode == 0 && !statesWithCustomShape?has_content><#-- shape not state dependent -->
			return SHAPE<#if offset>.move(state.getOffset(pos))</#if>;
			<#else><#-- shape is state dependent -->
			return shapes.apply(state)<#if offset>.move(state.getOffset(pos))</#if>;
			</#if>
		}
	</#if>

	<#if data.renderType() == 4>
	@Override protected RenderShape getRenderShape(BlockState state) {
		return RenderShape.INVISIBLE;
	}
	</#if>

	<#if data.blockBase?has_content && data.blockBase == "Stairs">
	@Override public float getExplosionResistance() {
		return ${data.resistance}f;
	}
	</#if>

	<#if data.connectedSides>
	@Override public boolean skipRendering(BlockState state, BlockState adjacentBlockState, Direction side) {
		return adjacentBlockState.getBlock() == this ? true : super.skipRendering(state, adjacentBlockState, side);
	}
	</#if>

	<#if data.hasCustomOpacity>
		<#if (!data.blockBase?has_content || data.blockBase == "Leaves") && data.lightOpacity == 0>
		@Override public boolean propagatesSkylightDown(BlockState state) {
			return <#if data.isWaterloggable>state.getFluidState().isEmpty()<#else>true</#if>;
		}
		</#if>

		<#if !data.blockBase?has_content || data.blockBase == "Leaves" || data.lightOpacity != 15>
		@Override public int getLightBlock(BlockState state) {
			<#if data.isWaterloggable && data.lightOpacity == 0> <#-- Prevent fully transparent blocks from overriding water opacity -->
				return propagatesSkylightDown(state) ? 0 : 1;
			<#else>
				return ${data.lightOpacity};
			</#if>
		}
		</#if>
	</#if>

	<#if data.hasTransparency && !data.blockBase?has_content>
	@Override public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}
	</#if>

	<#if data.rotationMode != 0 || data.isWaterloggable || filteredCustomProperties?has_content>
	@Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		<#assign props = []>
		<#if data.rotationMode == 5>
			<#assign props += ["AXIS"]>
		<#elseif data.rotationMode != 0>
			<#assign props += ["FACING"]>
			<#if (data.rotationMode == 1 || data.rotationMode == 3) && data.enablePitch>
				<#assign props += ["FACE"]>
			</#if>
		</#if>
		<#list filteredCustomProperties as prop>
			<#assign props += [prop.property().getName().replace("CUSTOM:", "")?upper_case]>
		</#list>
		<#if data.isWaterloggable>
			<#assign props += ["WATERLOGGED"]>
		</#if>
		builder.add(${props?join(", ")});
	}

	@Override public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null) return null;

		<#if data.isWaterloggable>
		boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
		</#if>
		<#if data.rotationMode != 3>
		return state
			<#if data.rotationMode == 1>
			<#if data.enablePitch>
			.setValue(FACE, faceForDirection(context.getNearestLookingDirection()))
			</#if>
			.setValue(FACING, context.getHorizontalDirection().getOpposite())
			<#elseif data.rotationMode == 2>
			.setValue(FACING, context.getNearestLookingDirection().getOpposite())
			<#elseif data.rotationMode == 4>
			.setValue(FACING, context.getClickedFace())
			<#elseif data.rotationMode == 5>
			.setValue(AXIS, context.getClickedFace().getAxis())
			</#if>
			<@initCustomBlockStateProperties />
			<#if data.isWaterloggable>
			.setValue(WATERLOGGED, flag)
			</#if>;
		<#elseif data.rotationMode == 3>
		if (context.getClickedFace().getAxis() == Direction.Axis.Y)
			return state
				<#if data.enablePitch>
				.setValue(FACE, context.getClickedFace().getOpposite() == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR)
				.setValue(FACING, context.getHorizontalDirection())
				<#else>
				.setValue(FACING, Direction.NORTH)
				</#if>
				<@initCustomBlockStateProperties />
				<#if data.isWaterloggable>
				.setValue(WATERLOGGED, flag)
				</#if>;

		return state
			<#if data.enablePitch>
			.setValue(FACE, AttachFace.WALL)
			</#if>
			.setValue(FACING, context.getClickedFace())
			<@initCustomBlockStateProperties />
			<#if data.isWaterloggable>
			.setValue(WATERLOGGED, flag)
			</#if>;
		</#if>
	}
	</#if>

	<#macro initCustomBlockStateProperties>
		<#list filteredCustomProperties as prop>
			<#assign propName = prop.property().getName()>
			.setValue(${propName.replace("CUSTOM:", "")?upper_case},
				<#if prop.property().getClass().getSimpleName().equals("StringType")>
					<#if propName.startsWith("CUSTOM:")>
					${StringUtils.snakeToCamel(propName.replace("CUSTOM:", ""))}Property.${prop.value()?upper_case}
					<#else>
					${propName?upper_case}.getValue("${prop.value()}").get()
					</#if>
				<#else>
				${prop.value()}
				</#if>
			)
		</#list>
	</#macro>

	<#if data.rotationMode != 0>
		<#if data.rotationMode != 5>
		public BlockState rotate(BlockState state, Rotation rot) {
			return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
		}

		public BlockState mirror(BlockState state, Mirror mirrorIn) {
			return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
		}
		<#else>
		@Override public BlockState rotate(BlockState state, Rotation rot) {
			return RotatedPillarBlock.rotatePillar(state, rot);
		}
		</#if>

		<#if data.rotationMode == 1 && data.enablePitch>
		private AttachFace faceForDirection(Direction direction) {
			if (direction.getAxis() == Direction.Axis.Y)
				return direction == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR;
			else
				return AttachFace.WALL;
		}
		</#if>
	</#if>

	<#if hasProcedure(data.placingCondition)>
	@Override public boolean canSurvive(BlockState blockstate, LevelReader worldIn, BlockPos pos) {
		if (worldIn instanceof LevelAccessor world) {
			int x = pos.getX();
			int y = pos.getY();
			int z = pos.getZ();
			return <@procedureOBJToConditionCode data.placingCondition/>;
		}
		return super.canSurvive(blockstate, worldIn, pos);
	}
	</#if>

	<#if data.isWaterloggable>
	@Override public FluidState getFluidState(BlockState state) {
		return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
	}
	</#if>

	<#if data.isWaterloggable || hasProcedure(data.placingCondition)>
	@Override public BlockState updateShape(BlockState state, LevelReader world, ScheduledTickAccess scheduledTickAccess, BlockPos currentPos, Direction facing, BlockPos facingPos, BlockState facingState, RandomSource random) {
		<#if data.isWaterloggable>
		if (state.getValue(WATERLOGGED)) {
			scheduledTickAccess.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(world));
		}
		</#if>
		return <#if hasProcedure(data.placingCondition)>
		!state.canSurvive(world, currentPos) ? Blocks.AIR.defaultBlockState() :
		</#if> super.updateShape(state, world, scheduledTickAccess, currentPos, facing, facingPos, facingState, random);
	}
	</#if>

	<#if data.canProvidePower && data.emittedRedstonePower??>
	@Override public boolean isSignalSource(BlockState state) {
		return true;
	}

	@Override public int getSignal(BlockState blockstate, BlockGetter blockAccess, BlockPos pos, Direction direction) {
		<#if hasProcedure(data.emittedRedstonePower)>
			int x = pos.getX();
			int y = pos.getY();
			int z = pos.getZ();
			Level world = (Level) blockAccess;
			return (int) <@procedureOBJToNumberCode data.emittedRedstonePower/>;
		<#else>
			return ${data.emittedRedstonePower.getFixedValue()};
		</#if>
	}
	</#if>

	<#if data.creativePickItem?? && !data.creativePickItem.isEmpty()>
	@Override public ItemStack getCloneItemStack(LevelReader world, BlockPos pos, BlockState state, boolean includeData) {
		return ${mappedMCItemToItemStackCode(data.creativePickItem, 1)};
	}
	<#elseif !data.hasBlockItem && (data.blockBase! != "FlowerPot")>
	@Override public ItemStack getCloneItemStack(LevelReader world, BlockPos pos, BlockState state, boolean includeData) {
		return ItemStack.EMPTY;
	}
	</#if>

	<#if data.xpAmountMax != 0>
	@Override protected void spawnAfterBreak(BlockState state, ServerLevel level, BlockPos pos, ItemStack tool, boolean dropExperience) {
		super.spawnAfterBreak(state, level, pos, tool, dropExperience);
		if (dropExperience)
		    this.tryDropExperience(level, pos, tool, <#if data.xpAmountMin == data.xpAmountMax>ConstantInt.of(${data.xpAmountMin}<#else>UniformInt.of(${data.xpAmountMin}, ${data.xpAmountMax}</#if>));
	}
	</#if>

	<@onBlockAdded data.onBlockAdded, hasProcedure(data.onTickUpdate) && data.shouldScheduleTick(), data.tickRate/>

	<@onRedstoneOrNeighborChanged data.onRedstoneOn, data.onRedstoneOff, data.onNeighbourBlockChanges/>

	<#if hasProcedure(data.onTickUpdate)>
	@Override public void <#if data.tickRandomly>randomTick<#else>tick</#if>(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
		super.<#if data.tickRandomly>randomTick<#else>tick</#if>(blockstate, world, pos, random);
		<@procedureCode data.onTickUpdate, {
			"x": "pos.getX()",
			"y": "pos.getY()",
			"z": "pos.getZ()",
			"world": "world",
			"blockstate": "blockstate"
		}/>

		<#if data.shouldScheduleTick()>
		world.scheduleTick(pos, this, ${data.tickRate});
		</#if>
	}
	</#if>

	<@onAnimateTick data.onRandomUpdateEvent/>

	<@onDestroyedByPlayer data.onDestroyedByPlayer/>

	<@onDestroyedByExplosion data.onDestroyedByExplosion/>

	<@onStartToDestroy data.onStartToDestroy/>

	<@onEntityCollides data.onEntityCollides/>

	<@onEntityWalksOn data.onEntityWalksOn/>

	<@onEntityFallsOn data.onEntityFallsOn/>

	<@onHitByProjectile data.onHitByProjectile/>

	<@onBlockPlacedBy data.onBlockPlayedBy/>

	<#if hasProcedure(data.onRightClicked) || data.shouldOpenGUIOnRightClick()>
	@Override
	public InteractionResult useWithoutItem(BlockState blockstate, Level world, BlockPos pos, Player entity, BlockHitResult hit) {
		super.useWithoutItem(blockstate, world, pos, entity, hit);
		<#if data.shouldOpenGUIOnRightClick()>
		if(entity instanceof ServerPlayer player)
			player.openMenu(world.getBlockEntity(pos) instanceof MenuProvider menuProvider ? menuProvider : null);
		</#if>

		<#if hasProcedure(data.onRightClicked)>
			int x = pos.getX();
			int y = pos.getY();
			int z = pos.getZ();
			double hitX = hit.getLocation().x;
			double hitY = hit.getLocation().y;
			double hitZ = hit.getLocation().z;
			Direction direction = hit.getDirection();
			<#if hasReturnValueOf(data.onRightClicked, "actionresulttype")>
			InteractionResult result = <@procedureOBJToInteractionResultCode data.onRightClicked/>;
			<#else>
			<@procedureOBJToCode data.onRightClicked/>
			</#if>
		</#if>

		<#if data.shouldOpenGUIOnRightClick() || !hasReturnValueOf(data.onRightClicked, "actionresulttype")>
		return InteractionResult.SUCCESS;
		<#else>
		return result;
		</#if>
	}
	</#if>

	<#if data.isBonemealable && !(data.blockBase?has_content && data.blockBase == "TrapDoor")>
	<@bonemealEvents data.isBonemealTargetCondition, data.bonemealSuccessCondition, data.onBonemealSuccess/>
	</#if>

	<#if data.hasInventory>
		@Override public MenuProvider getMenuProvider(BlockState state, Level worldIn, BlockPos pos) {
			BlockEntity tileEntity = worldIn.getBlockEntity(pos);
			return tileEntity instanceof MenuProvider menuProvider ? menuProvider : null;
		}

		@Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
			return new ${name}BlockEntity(pos, state);
		}

		@Override
		public boolean triggerEvent(BlockState state, Level world, BlockPos pos, int eventID, int eventParam) {
			super.triggerEvent(state, world, pos, eventID, eventParam);
			BlockEntity blockEntity = world.getBlockEntity(pos);
			return blockEntity != null && blockEntity.triggerEvent(eventID, eventParam);
		}

		<#if data.inventoryDropWhenDestroyed>
		@Override protected void affectNeighborsAfterRemoval(BlockState blockstate, ServerLevel world, BlockPos blockpos, boolean flag) {
			Containers.updateNeighboursAfterDestroy(blockstate, world, blockpos);
		}
		</#if>

		<#if data.inventoryComparatorPower>
		@Override public boolean hasAnalogOutputSignal(BlockState state) {
			return true;
		}

		@Override public int getAnalogOutputSignal(BlockState blockState, Level world, BlockPos pos, Direction direction) {
			BlockEntity tileentity = world.getBlockEntity(pos);
			if (tileentity instanceof ${name}BlockEntity be)
				return AbstractContainerMenu.getRedstoneSignalFromContainer(be);
			else
				return 0;
		}
		</#if>
	</#if>

	<#if data.sensitiveToVibration && data.hasInventory>
	@Override public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState blockstate, BlockEntityType<T> blockEntityType) {
		if (!level.isClientSide() && blockEntityType == ${JavaModName}BlockEntities.${REGISTRYNAME}) {
			return (_level, pos, state, blockEntity) -> {
				if (blockEntity instanceof ${name}BlockEntity be)
					VibrationSystem.Ticker.tick(_level, be.getVibrationData(), be.getVibrationUser());
			};
		}
		return null;
	}
	</#if>

	<#if data.tintType != "No tint">
		public static void blockColorLoad() {
			ColorProviderRegistry.BLOCK.register((bs, world, pos, index) -> {
				<#if data.tintType == "Default foliage">
					return FoliageColor.FOLIAGE_DEFAULT;
				<#elseif data.tintType == "Birch foliage">
					return FoliageColor.FOLIAGE_BIRCH;
				<#elseif data.tintType == "Spruce foliage">
					return FoliageColor.FOLIAGE_EVERGREEN;
				<#else>
					return world != null && pos != null ?
					<#if data.tintType == "Grass">
						BiomeColors.getAverageGrassColor(world, pos) : GrassColor.get(0.5D, 1.0D);
					<#elseif data.tintType == "Foliage">
						BiomeColors.getAverageFoliageColor(world, pos) : FoliageColor.FOLIAGE_DEFAULT;
					<#elseif data.tintType == "Water">
						BiomeColors.getAverageWaterColor(world, pos) : -1;
					<#elseif data.tintType == "Sky">
						Minecraft.getInstance().level.getBiome(pos).value().getSkyColor() : 8562943;
					<#elseif data.tintType == "Fog">
						Minecraft.getInstance().level.getBiome(pos).value().getFogColor() : 12638463;
					<#else>
						Minecraft.getInstance().level.getBiome(pos).value().getWaterFogColor() : 329011;
					</#if>
				</#if>
			}, ${JavaModName}Blocks.${REGISTRYNAME});
		}
	</#if>

	<#list data.customProperties as prop>
		<#if prop.property().getName().startsWith("CUSTOM:") && prop.property().getClass().getSimpleName().equals("StringType")>
		<#assign propClassName = StringUtils.snakeToCamel(prop.property().getName().replace("CUSTOM:", ""))>
		public enum ${propClassName}Property implements StringRepresentable {
			<#list prop.property.getArrayData() as value>
			${value?upper_case}("${value}")<#sep>,
			</#list>;

			private final String name;

			private ${propClassName}Property(String name) {
				this.name = name;
			}

			@Override public String getSerializedName() {
				return this.name;
			}

			@Override public String toString() {
				return this.name;
			}
		}
		</#if>
	</#list>

	<#if data.hasSpecialInformation(w) && !(var_extends_class??)> <#-- Do not generate item class for secondary block templates -->
	public static class Item extends <#if data.isDoubleBlock()>DoubleHighBlock<#elseif data.blockBase! == "Sign">Sign<#elseif data.blockBase! == "HangingSign">HangingSign<#else>Block</#if>Item {

		public Item(Item.Properties properties) {
			super(${JavaModName}Blocks.${REGISTRYNAME}, <#if data.isSign()>${JavaModName}Blocks.${data.getWallRegistryNameUpper()}, </#if>properties);
		}

		<@addSpecialInformation data.specialInformation, "block." + modid + "." + registryname, true/>

	}
	</#if>
}
</@javacompress>
<#-- @formatter:on -->

<#function getClassName>
	<#if var_extends_class! == "WallSignBlock" || var_extends_class! == "WallHangingSignBlock"><#return data.getWallName()>
	<#else><#return name>
	</#if>
</#function>

<#function getBlockClass blockBase="">
	<#if var_extends_class??><#return var_extends_class>
	<#elseif data.hasGravity><#return "FallingBlock">
	<#elseif blockBase == "Stairs"><#return "StairBlock">
	<#elseif blockBase == "Pane"><#return "IronBarsBlock">
	<#elseif blockBase == "Leaves">
		<#if data.leavesParticleType?? || (data.tintType == "No tint")>
			<#return "UntintedParticleLeavesBlock">
		<#else>
			<#return "TintedParticleLeavesBlock">
		</#if>
	<#elseif blockBase == "Sign"><#return "StandingSignBlock">
	<#elseif blockBase == "HangingSign"><#return "CeilingHangingSignBlock">
	<#else><#return blockBase + "Block">
	</#if>
</#function>
